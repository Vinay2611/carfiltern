-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: custsql-ipg98.eigbox.net
-- Generation Time: Feb 28, 2017 at 08:27 AM
-- Server version: 5.6.33
-- PHP Version: 4.4.9
-- 
-- Database: `carfilter`
-- 
CREATE DATABASE `carfilter` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `carfilter`;

-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(200) NOT NULL,
  `admin_email` varchar(200) NOT NULL,
  `admin_username` varchar(200) NOT NULL,
  `password` varchar(250) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `admin`
-- 

INSERT INTO `admin` VALUES (1, 'Santosh Tiwari', 'dsvinfosolutions@gmail.com', 'admin', '$2y$10$vlki8tDzwECHxZWoAWbDv.njplEJcmG64Th/uquB64TTT101b/aYq', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `order`
-- 

CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `car_detail` text NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- 
-- Dumping data for table `order`
-- 

INSERT INTO `order` VALUES (1, 'Santosh Tiwari', '9029666913', 'avinash@dsvinfosolutions.com', 'i want this car', '401105', '47', '2014-01-17');
INSERT INTO `order` VALUES (2, 'Stefan', '88883', 'njnsjsnnf@hotmail.com', 'wfkwnfln', '8282', '54', '2019-01-17');
INSERT INTO `order` VALUES (3, 'amit', '9999999999', 'jaiswal_vinay@dsvinfosolutions.com', 'tesing mesahe', '999', '51', '2023-01-17');
INSERT INTO `order` VALUES (4, 'avinash', '88998898998', 'kiranbalap27@gmail.com', 'testing of dsvinfosolution', '401540', '45', '2023-01-17');
INSERT INTO `order` VALUES (5, 'James', '9876543219', 'apple@gmail.com', 'Citroen enquiry', '98765', '66', '2001-02-17');
INSERT INTO `order` VALUES (6, 'Jame', '999999999', 'qwer@gmail.com', 'tesi skie e e', '99990', '45', '2001-02-17');
INSERT INTO `order` VALUES (7, 'John', '8989898988', 'dsvinfosolutions@gmail.com', 'liknande bilaa', '7787', '54', '2001-02-17');
INSERT INTO `order` VALUES (8, 'Jimmy', '89888898898', 'jimm@gmail.com', 'jkdjfkdjkj', '989898', '35', '2017-02-01');
INSERT INTO `order` VALUES (9, 'fsdfsd', '435345', 'gdf@dfsgd', 'gdfgdfgsdfg', '435345', '35', '2017-02-01');
INSERT INTO `order` VALUES (10, 'asdds', '67676767', 'sdfs@gdfgd', 'dfsgdfgdsfgdfg', '676767', '59', '2017-02-01');
INSERT INTO `order` VALUES (11, 'dummy', '988989898', 'dsvinfosolutions@gmail.com', 'testing on 27 feb 2017', '98988888', '66', '2017-02-27');
INSERT INTO `order` VALUES (12, '', '', '', '', '', '62', '2017-02-28');

-- --------------------------------------------------------

-- 
-- Table structure for table `products`
-- 

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `product_image` text,
  `category` varchar(255) DEFAULT NULL,
  `monthly_cost` varchar(255) DEFAULT NULL,
  `gear` varchar(255) DEFAULT NULL,
  `seats` varchar(255) DEFAULT NULL,
  `fuel` varchar(255) DEFAULT NULL,
  `co` varchar(255) DEFAULT NULL,
  `fuel_consumtion` varchar(255) DEFAULT NULL,
  `size_cargo` varchar(255) DEFAULT NULL,
  `horse_power` varchar(255) DEFAULT NULL,
  `drive` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `total_mileage` varchar(255) DEFAULT NULL,
  `service_include` varchar(255) DEFAULT NULL,
  `insurance_include` varchar(255) DEFAULT NULL,
  `wintertype_include` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `feature` int(11) NOT NULL DEFAULT '0',
  `createdon` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 AUTO_INCREMENT=100 ;

-- 
-- Dumping data for table `products`
-- 

INSERT INTO `products` VALUES (34, 'Nissan Leaf', 'Acenta 30 Kwh', 'Sveriges mest populära elbil.', '5876874f65633.jpg', 'Mellan', '2999', 'Manuell', '5', 'Hybrid/EI', '10', '0', '400', '110', 'Framhjulsdriven', '2', '3000', 'Yes', 'No', 'Yes', 0, 0, '2017-01-11');
INSERT INTO `products` VALUES (35, 'Skoda Fabia', 'Tsi 86 Hk Drivers Edition', 'Fin liten småbil', '587688102a636.jpg', 'Smabil', '1795', 'Manuell', '5', 'Bensin', '110', '0.56', '320', '86', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 1, '2017-01-11');
INSERT INTO `products` VALUES (36, 'Volkswagen Polo', '1,2 TSI 90', 'Sveriges populäraste småbil', '5876889c3cb4f.png', 'Smabil', '1795', 'Manuell', '5', 'Bensin', '125', '0.52', '340', '90', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-11');
INSERT INTO `products` VALUES (37, 'Peugeot 208', 'ACTIVE PureTech', 'Snygg bil!', '58768922250b5.png', 'Smabil', '1799', 'Manuell', '5', 'Bensin', '130', '0.6', '400', '82', 'Bakhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 1, 0, '2017-01-11');
INSERT INTO `products` VALUES (38, 'Peugeot 508', 'ACTIVE BlueHdi 120 Aut', 'Fräsch bil!', '587689a58f9ad.png', 'Kombi', '2999', 'Automat', '5', 'Diesel', '105', '0.41', '600', '120', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 1, 0, '2017-01-11');
INSERT INTO `products` VALUES (39, 'Audi Q3', '2.0 TDI 150 Hk Sport quattro Proline', 'Fräsig bil', '58768a64c9fa8.png', 'SUV', '3495', 'Alla', '5', 'Diesel', '140', '0.56', '390', '150', 'Bakhjulsdriven', '3', '3000', 'Yes', 'No', 'No', 0, 0, '2017-01-11');
INSERT INTO `products` VALUES (40, 'Volvo V40', 'T2 Business Kinetic', 'Snygg Volvo.', '58768b2d85895.png', 'Mellan', '2895', 'Manuell', '4', 'Bensin', '90', '0.63', '453', '110', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 0, 0, '2017-01-11');
INSERT INTO `products` VALUES (41, 'Volvo XC60', 'D4 AWD Classic Momentum', 'Gammal men prisvärd SUV.', '58768bb71f050.png', 'SUV', '5174', 'Automat', '5', 'Diesel', '180', '0.2', '700', '210', 'Framhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 0, 0, '2017-01-11');
INSERT INTO `products` VALUES (42, 'Mercedes C200 Kombi', 'SE Edition', 'Vilken vagn!', '58768cd1988f7.png', 'Kombi', '4295', 'Automat', '5', 'Diesel', '134', '0.62', '567', '170', 'Bakhjulsdriven', '3', '3000', 'Yes', 'No', 'No', 0, 0, '2017-01-11');
INSERT INTO `products` VALUES (43, 'Renault Zoe', 'Zoe II', 'Liten elbil', '587a676758e24.jpg', 'Smabil', '2890', 'Automat', '4', 'Hybrid/EI', '10', '0.3', '112', '35', 'Fyrhjulsdriven', '3', '3000', 'Yes', 'No', 'Yes', 0, 0, '2017-01-13');
INSERT INTO `products` VALUES (44, 'Citroen Grand Picasso', 'Classic', '7 sits', '58792dc3703fa.png', 'Kombi', '3590', 'Manuell', '7', 'Bensin', '44', '0.87', '800', '110', 'Framhjulsdriven', '3', '4500', 'No', 'No', 'No', 0, 0, '2017-01-13');
INSERT INTO `products` VALUES (45, 'Seat Ibiza', '5D', 'häftig spanjor', '58792e546e1c1.png', 'Smabil', '1595', 'Manuell', '5', 'Bensin', '78', '0.53', '456', '120', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-13');
INSERT INTO `products` VALUES (46, 'Toyota Avensis', 'Activeplus', 'Prisvärd japan', '58792f2d39ab5.png', 'Kombi', '2495', 'Manuell', '5', 'Bensin', '150', '0.67', '760', '140', 'Bakhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-13');
INSERT INTO `products` VALUES (47, 'Kia Sportage', '2wd Comfort', 'snygg!', '58792fe1bf4dd.png', 'SUV', '3790', 'Manuell', '5', 'Bensin', '140', '0.75', '650', '160', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 0, 0, '2017-01-13');
INSERT INTO `products` VALUES (48, 'Bmw 118d', 'xDrive M-Sport', 'Bäste mellanklassaren', '5879309dd528b.png', 'Smabil', '3195', 'Manuell', '4', 'Diesel', '130', '0.39', '230', '180', 'Bakhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-13');
INSERT INTO `products` VALUES (49, 'Volkswagen Golf', '1,2 TSI 110 Hk', 'Sverigest mest sålda bil december 2016', '5883dcefed872.png', 'Mellan', '2395', 'Manuell', '5', 'Bensin', '110', '0,34', '450', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (50, 'Volskwagen Golf Sportcombi', '1,2 TSI 110 Hk', 'Stor kombi', '587a6945e8630.png', 'Kombi', '2495', 'Manuell', '5', 'Alla', '136', '0,62', '700', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (51, 'Audi A3 Sportback', '1.0 TFSI 116 Hk Proline', 'En finare Golf', '587a6a2f1f45b.png', 'Mellan', '2795', 'Manuell', '5', 'Bensin', '222', '0,34', '340', '116', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'No', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (52, 'Ford Fiesta', 'Titanium 80Hk 5-D', 'hh', '587a6be0e4077.jpg', 'Smabil', '1958', 'Manuell', '5', 'Bensin', '117', '0,43', '115', '80', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 1, '2017-01-14');
INSERT INTO `products` VALUES (53, 'Ford Kuga', '1,6 150 Hk FWD Titanium X', 'ss', '587a6ca60b0c4.png', 'SUV', '3345', 'Manuell', '5', 'Bensin', '143', '0,65', '780', '150', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (54, 'Hyundai I10', 'Comfort 1.0 MPI 66 Hk', 'qq', '587a6d5c1918a.png', 'Smabil', '1590', 'Manuell', '4', 'Bensin', '99', '0,43', '120', '66', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (55, 'Hyundai Tuscon', 'Comfort 1,7 CRDI', 'lll', '587a6ec9c3478.png', 'SUV', '3990', 'Manuell', '5', 'Diesel', '130', '0,65', '340', '100', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (56, 'Hyundai I30', 'Select 1.4', 'lkl', '587a6f34d994f.png', 'Mellan', '2790', 'Alla', '5', 'Bensin', '123', '0,56', '445', '100', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (57, 'Mitsubishi ASX', 'Komfort Plus 2.2 Automat AWD', 'w', '587a705a3751c.png', 'SUV', '3690', 'Automat', '5', 'Diesel', '160', '0,72', '500', '156', 'Fyrhjulsdriven', '3', '3000', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (58, 'Mazda MX-5', '', 'll', '587a70e441b07.jpg', 'Sport', '3590', 'Manuell', '2', 'Bensin', '180', '0,67', '80', '169', 'Bakhjulsdriven', '3', '3000', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (59, 'Mazda 3', 'Core 2.0 120 Hk 5-D', 'qq', '587a717716fcb.png', 'Mellan', '2590', 'Manuell', '5', 'Bensin', '122', '0,64', '280', '120', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (60, 'Mazda CX-3', 'Core 2.0 120 Hk', '333', '587a72061d0ea.png', 'SUV', '2490', 'Manuell', '5', 'Bensin', '221', '0,69', '130', '120', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (61, 'Nissan Qashqai', 'DIG-T115 Acenta Saftey Pack Connect', '34', '587a72debb093.png', 'SUV', '2790', 'Manuell', '5', 'Bensin', '143', '0,43', '555', '115', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (62, 'Opel Corsa', '5-D 1.4 ECOTEC 90 Hk', '.', '587a738396116.png', 'Smabil', '1995', 'Manuell', '5', 'Bensin', '178', '0,45', '220', '90', 'Framhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (63, 'Nissan Juke', 'N-Connecta Automat', '1', '587a7414d7ea6.jpg', 'SUV', '3199', 'Automat', '5', 'Bensin', '133', '0,39', '190', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (64, 'Opel Astra', 'Enjoy 1.0 Turbo ECOTEC S/S', '-', '587a74c384976.png', 'Mellan', '2695', 'Manuell', '5', 'Bensin', '137', '0,58', '350', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (65, 'Renault Megane', 'Life TCe 100', 'q', '587a7581ad418.png', 'Mellan', '2650', 'Manuell', '5', 'Diesel', '155', '0,61', '340', '100', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (66, 'Citroen C1', '5D', '.', '587a7a75c588c.jpg', 'Smabil', '1690', 'Manuell', '4', 'Bensin', '89', '0,34', '148', '68', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'No', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (67, 'Citroen C4 Cactus', '5D', '.', '587a7ae4ed01f.png', 'Mellan', '2190', 'Manuell', '4', 'Bensin', '100', '0,34', '300', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 1, 0, '2017-01-14');
INSERT INTO `products` VALUES (68, 'Honda Civic', '1.6 i-DTEC', ',', '587a7bb7db8be.png', 'Mellan', '2499', 'Manuell', '5', 'Bensin', '111', '0,5', '400', '100', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (69, 'Honda HR-V', '1.5 Bensin', '.', '587a7c25d14b3.png', 'SUV', '2995', 'Manuell', '5', 'Bensin', '100', '0,66', '500', '100', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'Yes', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (71, 'Porsche Macan', 'Stockholm Sport Edition', '.', '587a7d5b2dd16.png', 'SUV', '6995', 'Automat', '5', 'Bensin', '330', '0,9', '500', '340', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (72, 'Porsche Cayenne', 'Business', '.', '587a7e0142c01.png', 'SUV', '13995', 'Automat', '5', 'Bensin', '200', '0,80', '800', '340', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-14');
INSERT INTO `products` VALUES (73, 'Range Rover Evoque', 'Luxury Edition 150 Hk', '2', '587e353f4e844.png', 'SUV', '5650', 'Automat', '5', 'Diesel', '200', '0,78', '799', '150', 'Fyrhjulsdriven', '3', '5000', 'Yes', 'No', 'No', 0, 0, '2017-01-17');
INSERT INTO `products` VALUES (74, 'Peugeot 5008', 'ACTIVE PureTech 130 Hk', '7 sits!', '587e35c8966fb.png', 'Minibus', '2990', 'Manuell', '7', 'Bensin', '232', '0,9', '1000', '130', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'Yes', 0, 0, '2017-01-17');
INSERT INTO `products` VALUES (75, 'Peugeot 308 SW', 'PureTech 110', 's', '587e413b4e809.png', 'Kombi', '2490', 'Manuell', '5', 'Bensin', '240', '0,7', '640', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'Yes', 0, 0, '2017-01-17');
INSERT INTO `products` VALUES (76, 'Mazda CX-5', '2,5 Optimum AWD Aut', 'ö', '587e36bb7c425.png', 'SUV', '4390', 'Automat', '5', 'Bensin', '342', '0,99', '560', '192', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'Yes', 0, 0, '2017-01-17');
INSERT INTO `products` VALUES (77, 'Audi A1 Sportback', '1.0 TFSI 95 Hk Proline', ' s', '587e37d6e4e88.png', 'Smabil', '2295', 'Manuell', '4', 'Bensin', '80', '0,3', '110', '95', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'No', 0, 0, '2017-01-17');
INSERT INTO `products` VALUES (78, 'Seat Leon', '5D', 'En spansk Golf', '587e3881812fa.jpg', 'Mellan', '1995', 'Manuell', '5', 'Bensin', '174', '0,5', '400', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 1, '2017-01-17');
INSERT INTO `products` VALUES (79, 'Mercedes A200', 'STHLM Edition AMG SE Edition', 'c', '587e41e6e1718.jpg', 'Mellan', '2999', 'Automat', '4', 'Bensin', '111', '0,6', '200', '130', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'No', 0, 0, '2017-01-17');
INSERT INTO `products` VALUES (80, 'Volvo V90', 'D3 Business', 'x', '588112c996a2d.png', 'Kombi', '4995', 'Manuell', '5', 'Diesel', '222', '0,5', '444', '190', 'Framhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 0, 0, '2017-01-19');
INSERT INTO `products` VALUES (81, 'Peugeot 2008', 'PureTech 110 Aut', '..', '5883d3e3ea3c7.png', 'Kombi', '2349', 'Automat', '5', 'Bensin', '120', '0,5', '450', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (82, 'Subaru Levorg', 'GT', '.', '5883d4c63770d.png', 'Kombi', '3785', 'Automat', '5', 'Bensin', '222', '0,8', '650', '180', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (83, 'Subaru Forester', '2.0X', ',', '5883d5ea9f684.png', 'Kombi', '2999', 'Manuell', '5', 'Bensin', '232', '0,65', '330', '170', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (84, 'Subaru Outback', '2.5 I Base', 'e', '5883d6715885d.png', 'Kombi', '3699', 'Automat', '5', 'Bensin', '120', '0,7', '777', '200', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (85, 'Subaru XV', '1.6', '.', '5883d6e26203e.png', 'Mellan', '2595', 'Manuell', '5', 'Bensin', '333', '0,8', '560', '110', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (86, 'Volvo V60', 'T3 Kinetic Business', '.', '5883d7905cf33.png', 'Kombi', '3313', 'Manuell', '5', 'Bensin', '130', '0,5', '600', '170', 'Framhjulsdriven', '3', '4500', 'Yes', 'Yes', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (87, 'Skoda Fabia Komib', 'Style TSI 90', '.', '5883d8c0df0a1.jpg', 'Kombi', '1895', 'Manuell', '5', 'Bensin', '100', '0,6', '500', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (88, 'Skoda Octavia kombi', 'Ambition TSI 115', 'v', '5883d945eed4b.jpg', 'Kombi', '2495', 'Manuell', '5', 'Bensin', '100', '0,7', '700', '115', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (89, 'Skoda Rapid', 'Style TSI 110', '.', '5883d99fde091.png', 'Mellan', '2195', 'Manuell', '5', 'Bensin', '100', '0,7', '400', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (90, 'Skoda Yeti', 'World Cup Edition TSI 110', '.', '5883da40303c0.png', 'SUV', '2695', 'Manuell', '5', 'Bensin', '110', '0,5', '700', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (91, 'Mini ONE', '3-D', '.', '5883db1f4f12c.png', 'Smabil', '2095', 'Manuell', '4', 'Bensin', '110', '0,5', '110', '110', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (92, 'Mini Clubman', '136 Hk', '.', '5883dbbc68fc9.png', 'Kombi', '2945', 'Manuell', '4', 'Bensin', '110', '0,5', '340', '136', 'Framhjulsdriven', '3', '3000', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (93, 'Volkswagen Golf Sportcombi', '1,2 TSI 110 Hk', '.', '5883dd68de51d.png', 'Kombi', '2495', 'Manuell', '5', 'Bensin', '110', '0,5', '800', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (94, 'Bmw 520d', 'XDrive', 'v', '5883de0866a6b.png', 'Kombi', '4988', 'Automat', '5', 'Diesel', '110', '0,8', '790', '190', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (95, 'Bmw 218', 'Active Tourer', '.', '5883deac41f0a.png', 'Kombi', '2995', 'Manuell', '5', 'Bensin', '110', '0,5', '400', '110', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (96, 'Bmw 318d Touring', 'xDrive', '.', '5883df531f657.png', 'Kombi', '3995', 'Manuell', '5', 'Diesel', '110', '0,6', '600', '100', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (97, 'Bmw 218', 'Gran Tourer Advantage Edition', 'w', '5883dfddecc9d.png', 'Minibus', '3954', 'Manuell', '7', 'Bensin', '110', '0,8', '859', '140', 'Framhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (98, 'Bmw 225xe', 'Active Tourer plug-in Hybrid', '.', '5883e07077ea8.png', 'Kombi', '6349', 'Automat', '5', 'Hybrid/EI', '0', '0,10', '400', '110', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
INSERT INTO `products` VALUES (99, 'Bmw X3', 'xDrive 20d Model Sport', '.', '5883e0f475c46.png', 'SUV', '5566', 'Automat', '5', 'Diesel', '130', '0,6', '600', '200', 'Fyrhjulsdriven', '3', '4500', 'Yes', 'No', 'No', 0, 0, '2017-01-21');
